---
license: based on the corresponding Wikipedia entry
path: /etc/hosts
---

The computer file hosts is an operating system file that maps hostnames to IP addresses.