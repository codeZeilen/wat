---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /etc
---

/etc contains system-global configuration files, which affect the system's behavior for all users.