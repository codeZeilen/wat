---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /srv
---

/srv can contain data directories of services such as HTTP (/srv/www/) or FTP.