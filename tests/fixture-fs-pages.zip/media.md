---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /media
---

/media is intended as a mount point for external devices, such as hard drives or removable media (floppies, CDs, DVDs).