---
license: based on the corresponding Wikipedia entry
path: /etc/sudoers
---

The sudoers file contains a list of users or user groups with permission to execute a subset of commands while having the privileges of the root user or another specified user.