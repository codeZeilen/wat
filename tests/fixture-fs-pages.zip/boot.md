---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /boot
---

/boot contains files needed to start up the system, including the Linux kernel, a RAM disk image and bootloader configuration files.