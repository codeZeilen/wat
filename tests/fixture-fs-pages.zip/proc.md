---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /proc
---

/proc is a virtual filesystem that provides a mechanism for kernel to send information to processes.