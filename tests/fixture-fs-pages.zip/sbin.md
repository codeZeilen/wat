---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /sbin
---

/sbin contains important administrative commands that should generally only be employed by the superuser.