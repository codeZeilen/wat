---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /bin
---

/bin is a place for most commonly used terminal commands, like ls, mount, rm, etc.