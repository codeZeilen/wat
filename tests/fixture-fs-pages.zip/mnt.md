---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /mnt
---

/mnt is also a place for mount points, but dedicated specifically to "temporarily mounted" devices, such as network filesystems.