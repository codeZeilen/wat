---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /sys
---

/sys is a virtual filesystem that can be accessed to set or obtain information about the kernel's view of the system.