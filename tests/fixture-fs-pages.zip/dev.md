---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /dev
---

/dev contains all device files, which are not regular files but instead refer to various hardware devices on the system, including hard drives.