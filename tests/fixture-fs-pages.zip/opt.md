---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /opt
---

/opt can be used to store additional software for your system, which is not handled by the package manager.