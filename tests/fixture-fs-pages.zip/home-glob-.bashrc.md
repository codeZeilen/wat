---
path: /home/*/.bashrc
---

A file that is executed every time a new bash is started. Users often use it to configure aliases, functions, and environment variables.