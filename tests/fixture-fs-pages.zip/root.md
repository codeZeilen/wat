---
license: root directory descriptions originally created by contributors to the Ubuntu documentation wiki and based on https://help.ubuntu.com/community/LinuxFilesystemTreeOverview.
path: /root
---

/root is the superuser's home directory, not in /home/ to allow for booting the system even if /home/ is not available.